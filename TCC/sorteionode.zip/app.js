const express = require('express');
const exphbs = require('express-handlebars');
const path = require('path');
const bodyParser = require('body-parser');
const admin = require('firebase-admin');

const app = express();

// Configuração do Firebase
const serviceAccount = require('./firebase-config.json');
admin.initializeApp({
    credential: admin.credential.cert(serviceAccount),
    databaseURL: 'https://filmessorteio-default-rtdb.firebaseio.com/'
});
const db = admin.database();

// Configurações do Express
app.engine('handlebars', exphbs.engine());
app.set('view engine', 'handlebars');
app.set('views', path.join(__dirname, 'views'));
app.use(express.static(path.join(__dirname, 'public')));
app.use(bodyParser.urlencoded({ extended: true }));
app.use(bodyParser.json());

// Rotas
app.get('/', (req, res) => res.render('home'));
app.get('/favoritos', (req, res) => res.render('favoritos'));
app.get('/cadastrarFilme', (req, res) => res.render('cadastrarFilme'));
app.get('/todos', (req, res) => {
    db.ref('cadastrarFilme').once('value', (snapshot) => {
        const filmes = snapshot.val(); // Obtém os dados dos filmes
        const filmesArray = [];

        // Organiza os dados em um array
        for (let id in filmes) {
            filmesArray.push({ id, ...filmes[id] });
        }

        // Renderiza o template 'todos' com os dados
        res.render('todos', { filmes: filmesArray });
    });
});

// Rota para sorteio do filme
app.get('/sortearFilme', (req, res) => {
    const filmesRef = db.ref('cadastrarFilme');
    filmesRef.once('value')
        .then(snapshot => {
            const filmes = snapshot.val();
            const filmesArray = Object.values(filmes);  // Transformando o objeto em array

            // Sorteia um filme aleatoriamente
            const filmeAleatorio = filmesArray[Math.floor(Math.random() * filmesArray.length)];

            // Envia os dados do filme sorteado para o frontend
            res.render('sortearFilme', { filme: filmeAleatorio });
        })
        .catch(error => {
            console.error(error);
            res.status(500).send('Erro ao sortear o filme');
        });
});

app.post('/submit', (req, res) => {
    const { foto, tituloFilme, sinopse } = req.body;

    // Certifique-se de que as categorias existam ou sejam `false`
    const categorias = {
        classico: req.body.classico ? true : false,
        romance: req.body.romance ? true : false,
        fantasia: req.body.fantasia ? true : false,
        animacao: req.body.animacao ? true : false,
        audrey: req.body.audrey ? true : false,
        marilyn: req.body.marilyn ? true : false
    };

    if (!foto || !tituloFilme) {
        return res.status(400).send("Campos foto e título são obrigatórios.");
    }

    // Gera novo ID automaticamente
    const novoFilme = db.ref('cadastrarFilme').push();
    novoFilme.set({ foto, tituloFilme, sinopse, categorias })
        .then(() => res.send('Dados salvos com sucesso no Firebase!'))
        .catch(error => res.status(500).send('Erro ao enviar dados: ' + error.message));
});


const PORT = 3000;
app.listen(PORT, () => console.log(`Servidor rodando na porta ${PORT}`));
