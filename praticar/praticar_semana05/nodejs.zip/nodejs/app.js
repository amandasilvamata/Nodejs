// Semana 05 Node.js

// Hora de praticar

const moment = require('moment');

// data e hora atual
const agora = moment().format('DD/MM/YYYY HH:mm:ss');
console.log("Data e Hora:", agora);

const agoraUSA = moment().format('MM/DD/YYYY');
console.log("Data em padrão americano:", agoraUSA);

// adicionar
const seteDiasDepois = moment().add(7, 'days').format('DD/MM/YYYY');
console.log('7 dias depois:', seteDiasDepois);

const trintaAnosDepois= moment().add(30, 'years').format('DD/MM/YYYY');
console.log("30 anos depois:", trintaAnosDepois);

// subtrair 
const cincoDiasAntes = moment().subtract(5, 'days').format('DD/MM/YYYY');
console.log("5 dias antes:", cincoDiasAntes);

const umMesAntes = moment().subtract(1, 'month').format('DD/MM/YYYY');
console.log("1 mês antes:", umMesAntes);

// diferença
const dataInicial = moment('2023-01-01', 'YYYY-MM-DD');
const dataFinal = moment('2025-12-31', 'YYYY-MM-DD');
const diferenca = dataFinal.diff(dataInicial, 'years');
console.log("Diferença em anos:", diferenca);

