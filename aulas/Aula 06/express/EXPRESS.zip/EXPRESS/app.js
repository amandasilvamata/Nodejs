const express = require('express')

// boa prática chamar de app o express
const app = express()
const msg = 123456789

const porta = 8081

app.get("/", (req,res)=>{
    res.send("Olá minha página web")
})

app.get("/login", (req,res)=>{
    // só recebe no formato string, se não for string converta 
    res.send(msg.toString())
})

app.get("/user/:id/:nome",(req,res)=>{
    
    var id = req.params.id
    var nome = req.params.nome
    res.send("Id:" + id + " <br>Nome:" + nome)
})



// ultimo bloco do código pois primeiro precisa rodar tudo para depois receber a requisição
app.listen(porta, ()=>{
    console.log("Servidor rodando em http://localhost:8081")
})