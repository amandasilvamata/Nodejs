const express = require('express');
const exphbs = require('express-handlebars');
const axios = require('axios');

const app = express();

const OPENWEATHER_API_KEY = '54701b4bc6ef9315c43bf5d477bbebe1';

app.engine('handlebars', exphbs.engine());
app.set('view engine', 'handlebars');

app.use(express.static('public'));

app.use(express.urlencoded({ extended:true }));

app.get('/', (req,res)=>{
    res.render('home')
});
// rota post clima
app.post('/weather', async (req, res) =>{
    const city = req.body.city;

    if(!city) {
        return res.render('home', { error: 'Por favor, insira o nome de uma cidade.'});
    }

    try {
        const response = await axios.get(
            `https://api.openweathermap.org/data/2.5/weather?q=${city}&units=metric&appid=${OPENWEATHER_API_KEY}&lang=pt_br`
        );

        const weatherData = response.data;
        const weatherInfo = {
            city: weatherData.name,
            temperature: weatherData.main.temp,
            description: weatherData.weather[0].description,
            icon: `http://openweathermap.org/img/wn/${weatherData.weather[0].icon}@2x.png`,
        };

        res.render('home', { weatherInfo });
    } catch (error){
        res.render('home', { error: 'Não foi possível obter a previsão para esta cidade. '});
    }
});


const PORT = 3000;

app.listen(PORT, () => console.log(`Servidor rodando na porta ${PORT}`));

