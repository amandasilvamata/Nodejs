const moment = require('moment');

const agora = moment().format('DD/MM/YY HH:mm:ss');
console.log("Data e Hora Atual: ", agora);

const agora2 = moment().format('MM/DD/YYYY');
console.log(agora2)

const seteDiasDepois = moment().add(7, 'days').format('DD/MM/YY');
console.log("7 dias depois:", seteDiasDepois)

const cincoDiasAntes = moment().subtract(5, 'days').format('DD/MM/YYYY');
console.log("5 dias antes: ", cincoDiasAntes);

const dataInicial = moment('2023-01-01', 'YYYY-MM-DD');
const dataFinal = moment('2023-12-31', 'YYYY-MM-DD');
const diferenca = dataFinal.diff(dataInicial, 'days');
console.log("Diferença em dias: ", diferenca);